@echo off
title ������å����������
cd /d "%~dp0"
md data\˵�� 2>nul
for /f "tokens=4,5 delims=. " %%i in ('ver') do if %%i%%j leq 62 (
echo.&echo ��ǰϵͳ�汾�ϵͣ�����WinHttpЭ������ȷ���������غ�����...
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings" /f /v SecureProtocols  /t REG_DWORD /d 2688 1>nul
reg add "HKLM\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Internet Settings" /f /v SecureProtocols  /t REG_DWORD /d 2688 1>nul
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings\WinHttp" /f /v DefaultSecureProtocols  /t REG_DWORD /d 2688 1>nul
reg add "HKLM\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Internet Settings\WinHttp" /f /v DefaultSecureProtocols  /t REG_DWORD /d 2688 1>nul
)
:gitee
echo.&echo ʹ��CNB����...
for /f "tokens=4,5 delims=. " %%i in ('ver') do if %%i%%j leq 63 (
wscript.exe -e:vbs data\cnb.vbs
pause&exit
)
for /f "tokens=6 delims=. " %%i in ('ver') do if %%i geq 26100 (
cd /d data
powershell -Command "Invoke-WebRequest -Uri 'https://cnb.cool/SiHaiYiYeQiu/SoftCnKiller/-/git/raw/master/whitepath.txt' -OutFile 'whitepath.txt'"  -UseBasicParsing
powershell -Command "Invoke-WebRequest -Uri 'https://cnb.cool/SiHaiYiYeQiu/SoftCnKiller/-/git/raw/master/AppdataInfo.txt' -OutFile 'AppdataInfo.txt'"  -UseBasicParsing
powershell -Command "Invoke-WebRequest -Uri 'https://cnb.cool/SiHaiYiYeQiu/SoftCnKiller/-/git/raw/master/folder.txt' -OutFile 'folder.txt'"  -UseBasicParsing
powershell -Command "Invoke-WebRequest -Uri 'https://cnb.cool/SiHaiYiYeQiu/SoftCnKiller/-/git/raw/master/sign.txt' -OutFile 'sign.txt'"  -UseBasicParsing
powershell -Command "Invoke-WebRequest -Uri 'https://cnb.cool/SiHaiYiYeQiu/SoftCnKiller/-/git/raw/master/Descrip/%%E5%%85%%B3%%E4%%BA%%8Efolder%%E8%%AF%%B4%%E6%%98%%8E.txt' -OutFile '˵��\����folder˵��.txt'"  -UseBasicParsing
powershell -Command "Invoke-WebRequest -Uri 'https://cnb.cool/SiHaiYiYeQiu/SoftCnKiller/-/git/raw/master/Descrip/%%E5%%85%%B3%%E4%%BA%%8E%%E6%%95%%B0%%E7%%AD%%BEsign%%E8%%AF%%B4%%E6%%98%%8E.txt' -OutFile '˵��\������ǩsign˵��.txt'"  -UseBasicParsing
for /f %%a in ('dir /a /b folder.txt') do if %%~za geq 10000 (echo ������ϣ�) else (echo ���³��������ֶ�����ַ���أ�https://free.lanzoui.com/b0cpu1guf)
pause&exit
)
wscript.exe -e:vbs data\cnb.vbs
exit