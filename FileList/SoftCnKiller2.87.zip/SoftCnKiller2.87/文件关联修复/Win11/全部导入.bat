@echo off
%systemroot%\system32\net.exe session >nul 2>&1 || %systemroot%\system32\WindowsPowerShell\v1.0\powershell.exe -NoP -C "Start-Process -FilePath '%~f0' -Verb RunAs" && exit
cd /d %~dp0
for %%i in (*.reg) do regedit /s "%%i"