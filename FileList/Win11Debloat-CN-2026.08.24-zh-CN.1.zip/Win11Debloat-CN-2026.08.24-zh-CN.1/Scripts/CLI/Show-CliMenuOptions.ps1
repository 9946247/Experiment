﻿# Shows the CLI menu options and prompts the user to select one. Loops until a valid option is selected.
function Show-CliMenuOptions {
    Do { 
        $ModeSelectionMessage = "请选择选项 (1/2)" 

        Write-CliHeader '菜单'

        Write-Host "(1) Default mode: Quickly apply the recommended changes"
        Write-Host "(1) 默认模式：快速应用推荐的更改"

        # Only show this option if SavedSettings file exists
        if (Test-Path $script:SavedSettingsFilePath) {
            Write-Host "(3) 快速应用上次使用的设置"
            
            $ModeSelectionMessage = "请选择选项 (1/2/3)" 
        }

        Write-Host ""
        Write-Host ""

        $Mode = Read-Host $ModeSelectionMessage

        if (($Mode -eq '3') -and -not (Test-Path $script:SavedSettingsFilePath)) {
            $Mode = $null
        }
    }
    while ($Mode -ne '1' -and $Mode -ne '2' -and $Mode -ne '3')

    return $Mode
}