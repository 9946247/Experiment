﻿# Win11Debloat-CN 发行说明

## 版本信息

- 中文发行版本：`2026.08.24-zh-CN.1`
- 上游基线版本：`2026.08.24`
- 上游项目：[Raphire/Win11Debloat](https://github.com/Raphire/Win11Debloat)
- 上游作者：Raphire
- 中文本地化维护：被窝

## 本次更新

本版本已同步至 Win11Debloat `2026.08.24`，并完成对应界面、提示文本、配置可见文本和说明文档的简体中文本地化。

本次同步同时对汉化版本进行了兼容性复查，重点保证以下技术标识与上游保持一致：

- PowerShell 参数名
- FeatureId 与默认设置名称
- 配置文件结构键
- 注册表路径与注册表数据类型
- GUI 控件内部名称
- 脚本文件与模块调用关系

这些内部标识不会为了显示中文而改名，避免影响脚本逻辑、配置导入导出及目标用户模式。

## 上游 2026.08.24 同步内容

当前版本已包含对应上游基线中的主要更新，包括新的 Windows 调整项目、应用移除逻辑更新、注册表处理改进、错误处理改进以及相关兼容性修复。

具体上游变更以 [Raphire/Win11Debloat](https://github.com/Raphire/Win11Debloat) 的 `2026.08.24` 版本为准。

## 启动方式

解压发行包后，以管理员身份运行：

```text
Run.bat
```

如需手动启动，可使用 Windows PowerShell 5.1：

```powershell
.\Win11Debloat.ps1
```

不建议使用 PowerShell 7 (`pwsh`) 作为主脚本运行环境。

## 发行包完整性

正式发行包包含运行所需的脚本、配置、注册表文件、界面资源和说明文档，并附带：

```text
SHA256SUMS.txt
```

该文件用于校验发行包内文件完整性。

发行包不应包含运行过程中产生的本地状态或测试产物，例如：

- `Logs/`
- `Backups/`
- `Config/LastUsedSettings.json`
- `dist/`
- 嵌套压缩包

## 许可

本项目沿用上游 MIT License，并保留原始版权与许可文本。Win11Debloat-CN 为社区维护的简体中文本地化版本，并非上游官方发行版。