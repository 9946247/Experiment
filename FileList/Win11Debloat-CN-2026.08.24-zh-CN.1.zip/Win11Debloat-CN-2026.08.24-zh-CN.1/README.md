﻿# Win11Debloat-CN

**Win11Debloat-CN** 是 [Raphire/Win11Debloat](https://github.com/Raphire/Win11Debloat) 的简体中文本地化版本，在尽量保持上游功能与行为一致的基础上，对界面、提示文本和相关说明进行中文化。

- 当前版本：`2026.08.24-zh-CN.1`
- 上游基线：`2026.08.24`

## 项目说明

本项目主要面向希望以简体中文使用 Win11Debloat 的 Windows 11 用户。

汉化范围包括：

- 图形界面与主要操作提示
- PowerShell 控制台输出
- 配置项名称、说明及可见文本
- 项目使用说明与发行文档

除明确记录的本地化调整外，功能逻辑保持与对应上游版本一致。PowerShell 参数名、FeatureId、配置结构键、注册表路径等技术标识不会因汉化而改名，以保证脚本兼容性和后续上游同步。

## 主要功能

Win11Debloat 可用于集中调整 Windows 11 的常见设置，包括：

- 移除不需要的预装应用
- 调整隐私、遥测和推荐内容相关设置
- 调整开始菜单、任务栏和文件资源管理器行为
- 管理部分 Windows AI、组件和后台功能
- 使用预设快速应用一组优化项目
- 导入或导出配置，便于重复部署
- 在执行部分系统修改前创建备份或恢复点

实际可用项目会根据 Windows 版本和上游功能变化而调整。

## 使用方法

1. 从本项目的 [Releases](https://github.com/Beiwo992/Win11Debloat-CN/releases) 页面下载对应发行包。
2. 解压到本地目录。
3. 以管理员身份运行 `Run.bat`。
4. 按中文界面选择需要应用的项目。

也可以在解压目录中使用 **Windows PowerShell 5.1** 运行：

```powershell
.\Win11Debloat.ps1
```

建议使用发行包内的本地入口。上游提供的在线一键命令会下载上游原版，并不会启动本项目的中文版本。

## 使用前说明

本工具会修改 Windows 系统设置，部分选项还会移除系统预装应用。建议在应用较大范围修改前：

- 创建系统还原点或必要的注册表备份
- 保存重要数据
- 只启用自己确认需要的选项

## 与上游的关系

- 上游项目：[Raphire/Win11Debloat](https://github.com/Raphire/Win11Debloat)
- 上游作者：Raphire
- 中文本地化维护：被窝
- 当前上游基线：`2026.08.24`

Win11Debloat-CN 是社区维护的独立本地化版本，并非 Raphire 或 Win11Debloat 上游项目的官方中文发行版。

版本命名采用：

```text
上游版本-zh-CN.本地修订号
```

例如：`2026.08.24-zh-CN.1`。

## 更新与同步

- 本版本的具体发行信息见 [RELEASE.zh-CN.md](RELEASE.zh-CN.md)
- 上游同步与维护规则见 [UPSTREAM.md](UPSTREAM.md)

每次更新上游基线后，会重新检查脚本语法、配置结构、技术标识以及主要本地化差异，避免翻译影响原有功能。

## 许可与致谢

本项目沿用上游的 [MIT License](LICENSE)。原始版权信息保留如下：

```text
Copyright (c) 2020 Raphire (https://github.com/Raphire)
```

感谢 Raphire 及 Win11Debloat 项目的贡献者维护原项目。