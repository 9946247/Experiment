﻿# 上游同步说明

本文档用于记录 Win11Debloat-CN 与上游 [Raphire/Win11Debloat](https://github.com/Raphire/Win11Debloat) 的同步原则。

## 当前基线

- 上游项目：`Raphire/Win11Debloat`
- 上游版本：`2026.08.24`
- 中文发行版本：`2026.08.24-zh-CN.1`
- 中文本地化维护：被窝

## 同步原则

Win11Debloat-CN 以已发布的上游版本或标签作为同步基线。同步时优先保留上游脚本结构和内部标识，只翻译用户可见内容。

以下内容原则上保持上游原值，不进行中文化：

- PowerShell 参数、变量接口和函数调用约定
- FeatureId、CategoryId、GroupId 等内部 ID
- JSON 配置结构键
- XAML `x:Name` 和脚本使用的控件名称
- 注册表路径、注册表数据名和数据类型
- App ID、包名、命令名和文件路径
- Git、PowerShell 与 Windows API 使用的固定关键字

## 同步流程

1. 获取目标上游版本并记录对应 tag 或 commit。
2. 比较 `Win11Debloat.ps1`、`Scripts/`、`Schemas/`、`Config/`、`Regfiles/`、`Assets/` 与 `Run.bat` 的变化。
3. 先合并上游功能变更，再处理新增或变化的用户可见文本。
4. 对中文界面、提示、说明和配置描述进行本地化。
5. 检查技术标识是否被误翻译。
6. 校验 PowerShell、JSON 与 XAML/XML 语法。
7. 检查默认设置与 FeatureId 的对应关系，以及配置导入/导出结构。
8. 在测试环境中检查 GUI、管理员提升、目标用户模式和主要设置流程。
9. 更新 `README.md`、`RELEASE.zh-CN.md`、`VERSION` 和本文件中的版本信息。
10. 从干净目录重新生成发行包和 `SHA256SUMS.txt`。

## 版本命名

中文发行版本使用：

```text
上游版本-zh-CN.本地修订号
```

例如：

```text
2026.08.24-zh-CN.1
```

如果上游基线不变，仅修正翻译、说明或本地打包问题，则递增末尾修订号；同步到新的上游版本时更新前半部分版本号。

## 发布前检查

正式发布前至少确认：

- PowerShell 脚本无解析错误
- JSON 配置可正常解析
- XAML/XML 可正常解析
- 默认设置引用的 FeatureId 均存在
- 不存在被误翻译的技术参数键
- `Run.bat`、注册表文件和核心运行逻辑与目标上游基线兼容
- 发行包不包含日志、备份、LastUsedSettings 或测试目录
- `SHA256SUMS.txt` 与最终发行内容一致

## 项目关系

Win11Debloat-CN 是独立维护的社区中文本地化版本。上游项目及其原始实现、许可和版权归 Raphire 及相应贡献者所有。